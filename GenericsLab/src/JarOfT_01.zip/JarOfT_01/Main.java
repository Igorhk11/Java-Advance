package JarOfT_01;

import java.util.ArrayDeque;

public class Main {
    public static void main(String[] args) {

        Jar<Integer> jar = new Jar<>();
        jar.add(12);
        jar.add(13);
        jar.remove();

        
    }
}
